export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      applications: {
        Row: {
          area: string | null
          bust: string | null
          car_availability: string | null
          created_at: string
          date_of_birth: string | null
          district: string | null
          experience: string | null
          eye_color: string | null
          first_name: string
          governorate: string | null
          hair_color: string | null
          hair_length: string | null
          hair_type: string | null
          has_passport: boolean | null
          height: string | null
          hips: string | null
          id: string
          instagram: string | null
          is_brand_ambassador: boolean | null
          jacket_size: string | null
          language_levels: Json | null
          languages: Json | null
          last_name: string
          middle_name: string | null
          mobile: string | null
          nationality: string | null
          other_number: string | null
          pant_size: string | null
          photo_urls: string[] | null
          shoe_size: string | null
          shoulders: string | null
          skin_tone: string | null
          sport_levels: Json | null
          sports: Json | null
          talent_levels: Json | null
          talents: Json | null
          tiktok: string | null
          waist: string | null
          website: string | null
          weight: string | null
          whatsapp: string | null
          willing_to_travel: boolean | null
        }
        Insert: {
          area?: string | null
          bust?: string | null
          car_availability?: string | null
          created_at?: string
          date_of_birth?: string | null
          district?: string | null
          experience?: string | null
          eye_color?: string | null
          first_name: string
          governorate?: string | null
          hair_color?: string | null
          hair_length?: string | null
          hair_type?: string | null
          has_passport?: boolean | null
          height?: string | null
          hips?: string | null
          id?: string
          instagram?: string | null
          is_brand_ambassador?: boolean | null
          jacket_size?: string | null
          language_levels?: Json | null
          languages?: Json | null
          last_name: string
          middle_name?: string | null
          mobile?: string | null
          nationality?: string | null
          other_number?: string | null
          pant_size?: string | null
          photo_urls?: string[] | null
          shoe_size?: string | null
          shoulders?: string | null
          skin_tone?: string | null
          sport_levels?: Json | null
          sports?: Json | null
          talent_levels?: Json | null
          talents?: Json | null
          tiktok?: string | null
          waist?: string | null
          website?: string | null
          weight?: string | null
          whatsapp?: string | null
          willing_to_travel?: boolean | null
        }
        Update: {
          area?: string | null
          bust?: string | null
          car_availability?: string | null
          created_at?: string
          date_of_birth?: string | null
          district?: string | null
          experience?: string | null
          eye_color?: string | null
          first_name?: string
          governorate?: string | null
          hair_color?: string | null
          hair_length?: string | null
          hair_type?: string | null
          has_passport?: boolean | null
          height?: string | null
          hips?: string | null
          id?: string
          instagram?: string | null
          is_brand_ambassador?: boolean | null
          jacket_size?: string | null
          language_levels?: Json | null
          languages?: Json | null
          last_name?: string
          middle_name?: string | null
          mobile?: string | null
          nationality?: string | null
          other_number?: string | null
          pant_size?: string | null
          photo_urls?: string[] | null
          shoe_size?: string | null
          shoulders?: string | null
          skin_tone?: string | null
          sport_levels?: Json | null
          sports?: Json | null
          talent_levels?: Json | null
          talents?: Json | null
          tiktok?: string | null
          waist?: string | null
          website?: string | null
          weight?: string | null
          whatsapp?: string | null
          willing_to_travel?: boolean | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
